--Subqueries and Joins
-- Users who placed more than 5 orders
SELECT user_id, COUNT(*) AS total_orders
FROM orders
GROUP BY user_id
HAVING COUNT(*) > 5;

-- Users whose average order amount is more than $500
SELECT user_id, AVG(amount) AS avg_order
FROM orders
GROUP BY user_id
HAVING AVG(amount) > 500;

-- Users who placed their first order in the last 30 days
SELECT u.id, u.name
FROM users u
JOIN (
    SELECT user_id, MIN(order_date) AS first_order
    FROM orders
    GROUP BY user_id
) o ON u.id = o.user_id
WHERE o.first_order >= CURRENT_DATE - INTERVAL '30 days';
