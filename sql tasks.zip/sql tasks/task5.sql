
--Trigger to Track Deleted Records
-- Employees table
CREATE TABLE employees (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    position VARCHAR(100),
    salary DECIMAL
);

-- Archive table
CREATE TABLE deleted_employees (
    id INT,
    name VARCHAR(100),
    position VARCHAR(100),
    salary DECIMAL,
    deleted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Trigger function
CREATE OR REPLACE FUNCTION archive_deleted_employee()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO deleted_employees (id, name, position, salary, deleted_at)
    VALUES (OLD.id, OLD.name, OLD.position, OLD.salary, CURRENT_TIMESTAMP);
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
CREATE TRIGGER after_employee_delete
AFTER DELETE ON employees
FOR EACH ROW
EXECUTE FUNCTION archive_deleted_employee();
