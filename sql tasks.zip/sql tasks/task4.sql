 --School System Normalized Schema

-- Students
CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE
);

-- Teachers
CREATE TABLE teachers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    subject VARCHAR(100)
);

-- Courses
CREATE TABLE courses (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    teacher_id INT REFERENCES teachers(id)
);

-- Enrollments (many-to-many between students and courses)
CREATE TABLE enrollments (
    student_id INT REFERENCES students(id),
    course_id INT REFERENCES courses(id),
    enrollment_date DATE,
    PRIMARY KEY(student_id, course_id)
);

-- Example INSERTs
INSERT INTO students (name, email) VALUES ('Alice', 'alice@example.com');
INSERT INTO teachers (name, subject) VALUES ('Mr. Smith', 'Math');
INSERT INTO courses (name, teacher_id) VALUES ('Algebra 101', 1);
INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (1, 1, '2025-01-15');

-- Example SELECTs
-- Get all courses a student is enrolled in
SELECT s.name AS student, c.name AS course
FROM enrollments e
JOIN students s ON e.student_id = s.id
JOIN courses c ON e.course_id = c.id;
