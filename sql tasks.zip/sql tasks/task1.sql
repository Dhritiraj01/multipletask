-- Total sales amount per customer
SELECT customer_id, SUM(amount) AS total_sales
FROM sales
GROUP BY customer_id;

--Top 5 customers by sales
SELECT customer_id, SUM(amount) AS total_sales
FROM sales
GROUP BY customer_id
ORDER BY total_sales DESC
LIMIT 5;

-- Count how many sales happened in the last 7 days
SELECT COUNT(*) AS sales_last_7_days
FROM sales
WHERE sale_date >= CURRENT_DATE - INTERVAL '7 days';

-- List customers who havenot made any purchase in 2024
-- Assuming there is a customers table
SELECT id, name
FROM customers
WHERE id NOT IN (
    SELECT DISTINCT customer_id
    FROM sales
    WHERE sale_date >= '2024-01-01' AND sale_date < '2025-01-01'
);
